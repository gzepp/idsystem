import React from "react";

import "./pageNotFound.css";

function pageNotfound() {
  return (
    <div className="error-body">
      <div className="error-contents">
        <div className="error-404-cont"></div>
      </div>
    </div>
  );
}

export default pageNotfound;
