import React, { useState, useEffect } from "react";
import "./comp_css/print_footer.css";

export default function PrintFooter() {
  return (
    <div className="footer-body-container">
      
      <div className="footer-container">
        <div className="footer-text">
          <div className="footer-school-contact">Tel No.: (044) 815-6739  |  Mobile No.: 0917-425-1963  |  E-mail: shabulacan@gmail.com</div>
        </div>
      </div>
    
    </div>
  );
}
