if (!window.crypto) {
  window.crypto = require("crypto-browserify");
}
