export const api_key = "655739465551728";
export const cloud_name = "debe9q66f";
