const domain = "https://shams-uiid-backend.onrender.com/";

export default domain;
