const secretKey = "B9AgaSzrDTyqY7l0be1ccPWNojw+GcMJXpg4nofxC/g=";

export default secretKey;
