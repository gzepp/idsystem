import domain from "./domain";
import secretKey from "./sskey";
import { api_key, cloud_name } from "./cloudinary";

export { domain, api_key, cloud_name, secretKey };
